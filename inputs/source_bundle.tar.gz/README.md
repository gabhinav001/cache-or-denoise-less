# Before Caching: Denoising Budgets and Residual Reuse in Robot Policies

Anonymous code, result artifacts, and reproduction harness for the workshop paper.

## Overview

This repository provides the complete implementation, experimental results, and reproduction harness for the workshop paper **"Before Caching: Denoising Budgets and Residual Reuse in Robot Policies"**.

We investigate the mechanics, failure modes, and efficiency tradeoffs of residual caching in diffusion and flow-matching robot policies:

1. **Configuration Dependence & Stale-Cache Action Error Diagnostic:**
   Cache stability across inference cycles is strongly configuration-dependent:
   - In a 50-state audit, upstream Fast-WAM's unconditional model ($\sigma\text{-shift}=5.0$) reproduces high success (**92.0%–94.0% vs. 94.0% stock**). A single-state diagnostic (task 0, initial state 0, cycle 4, 4-cycle-old cache) shows action prediction error is minimal (**0.40%**; $4.02\times 10^{-3}$).
   - Under conditional IDM ($\sigma\text{-shift}=1.0$), unattenuated caching drops to **60.0%–62.0%** (vs. 98.0% stock; 67.6% across 500 episodes over 100 states), while single-state action error increases $14.8\times$ to **5.96%** ($5.96\times 10^{-2}$).
   - Because checkpoint weights and schedules change together, noise-schedule refinement is treated as an explanatory hypothesis rather than an isolated cause.
   - Least-squares residual attenuation ($\beta$) counteracts this degradation, recovering **+15.2 percentage points** across 5 seeds under fixed arm ordering (82.8% vs. 67.6%).

2. **Whole-Stack vs. Blockwise Execution:**
   - Whole-stack substitution ($h_L = h_0 + R$) bypasses the entire 30-block execution loop during reuse cycles, delivering a verified **1.71× cycle speedup** (97.1 ms mean cycle vs. 166.4 ms stock; 81.7 ms reuse vs. 173.6 ms refresh on an RTX 6000 Ada GPU).
   - Blockwise substitution individually hooks each block, executing at 148.1 ms/cycle compiled due to graph dispatch and retained computation overhead.

3. **Denoising Budgets & Latency Bimodality:**
   - Short uncached inference (2 steps, 123.6 ms, 96.6% success) strictly Pareto-dominates the tested 10-step attenuated blockwise cache (221.8 ms, 93.6%) by **+3.0 percentage points** on 500 LIBERO Goal states.
   - Periodic caching exhibits severe bimodal latency (418.5 ms refresh vs. 259.6 ms reuse, p95 455.9 ms over 366 calls on RTX A6000 pilot), which short uncached policies avoid by removing periodic refresh computation entirely.

---

## Quick Start: Verify on CPU (No GPU Required)

The full evaluation pipeline, mathematical derivations, schedule sensitivity analysis, and figure data can be verified locally on CPU in seconds:

```bash
# 1. Run the focused workshop verifier suite (7 test suites)
bash repro/verify_workshop.sh

# 2. Re-derive post-hoc schedule sensitivity analysis across 500 states
python3 probes/report_schedule_sensitivity.py

# 3. Check anonymity across all repository files
python3 probes/check_anonymity.py
```

### What `verify_workshop.sh` tests:
- **Cache Semantics & Identities:** Verifies algebraic identity gates ($< 5 \times 10^{-3}$), BF16 stability, and staleness-aware substitution.
- **Checkpoint Coverage:** Proves strict parameter coverage and shape compatibility for action and video experts.
- **Sensitivity & Pairing:** Verifies all 24 raw source checksums, Monte Carlo bootstrap confidence intervals, and task-stratified state coverage across the 500-state evaluation benchmark.
- **Figure Integrity:** Bit-for-bit check matching all 8 plotted frontier points, intervals, and error bars in `probes/workshop_figure_data.json`.

---

## Reproduce Experiments on GPU

For hardware and environment prerequisites, see [setup/HOST_REQUIREMENTS.md](setup/HOST_REQUIREMENTS.md). Each experiment is mapped to its raw artifacts and analysis script in [repro/AUDIT_MAP.md](repro/AUDIT_MAP.md).

### 1. Environment Setup & Host Preflight
```bash
# Provision container environment (LIBERO + MuJoCo 3.3.2 + EGL + PyTorch)
# Fetches checkpoint and configures environment:
bash setup/onstart_libero_shrink.sh

# Verify host readiness:
./repro/run_experiment.sh preflight
```

### 2. Unified Matched Frontier & Decisive Evaluation (Table 3b, §4, & §5)
Evaluates the 1-step latency floor, 2-step short uncached, 10-step full compute, whole-stack plain, whole-stack preaggregated attenuation, blockwise plain, and blockwise explicit skip attenuation under conditional IDM ($s=1.0$), as well as 1-step, 2-step, 10-step, and native whole-stack caching under unconditional Fast-WAM ($s=5.0$) on a single host (50 shared states, seed 42, fresh processes, cycle-synchronized CUDA timing):
```bash
# Reproduce Table 3b and §5 contrasts from stored evaluation artifacts:
python3 probes/report_decisive_eval.py results/decisive_review_eval

# Re-run full 11-arm evaluation on an NVIDIA RTX A6000 host:
./repro/run_experiment.sh decisive_review_eval --out results_new/decisive_review_eval
python3 probes/report_decisive_eval.py results_new/decisive_review_eval

# Historical 6-arm matched frontier collection (RTX A6000 initial run):
python3 probes/report_matched_frontier.py results/matched_frontier
```

### 3. Fresh-Process Attenuation Replication (§3)
Evaluates plain vs. attenuated caching in independent fresh processes across 100 shared benchmark states (seeds 42 and 7) on an RTX A6000:
```bash
# Run fresh-process replication:
./repro/run_experiment.sh tau8_fresh --out results_new/tau8_fresh

# Compute paired differences and state-clustered bootstrap interval:
python3 probes/report_tau8_fresh.py results_new/tau8_fresh
```

### 4. 500-State Schedule Frontier (Figure 1 & §4)
Evaluates 2-step uncached, 4-step uncached, 4-step cached, and 10-step cached inference across 500 distinct initial states on LIBERO Goal:
```bash
# Run 500 states for seed 42 and seed 7:
./repro/run_experiment.sh statescale --out results_new/statescale
WAM_SEED=7 ./repro/run_experiment.sh statescale --out results_new/statescale

# Compute paired statistics and sensitivity analysis:
python3 probes/report_statescale.py results_new/statescale
python3 probes/report_schedule_sensitivity.py
```

### 5. Configuration Sensitivity Baseline Audit (Table 3a & §5)
Audits configuration dependence between upstream Fast-WAM ($\sigma\text{-shift}=5.0$) and conditional IDM ($\sigma\text{-shift}=1.0$) across stock, whole-stack, and blockwise execution:
```bash
# Optional: archive and export exact source tree SHA256
tar -czf source_bundle.tar.gz probes repro
export WAM_SOURCE_BUNDLE_SHA256=$(sha256sum source_bundle.tar.gz | cut -d' ' -f1)

# Evaluate original FastWAM scheduler (sigma-shift=5.0)
BASELINE_VARIANT=original BASELINE_PHASE=pilot \
  bash repro/run_experiment.sh baseline_audit --seeds 42 --out out/baseline_audit
python3 probes/report_baseline_audit.py out/baseline_audit --variant original

# Evaluate conditional IDM scheduler (sigma-shift=1.0)
BASELINE_VARIANT=optional BASELINE_PHASE=pilot \
  bash repro/run_experiment.sh baseline_audit --seeds 42 --out out/baseline_audit
python3 probes/report_baseline_audit.py out/baseline_audit --variant optional
```

### 6. Residual Geometry & Weight Fitting (Table 1 & §3)
```bash
# Refit least-squares per-cell weights from Gram matrices (runs on CPU anywhere):
./repro/run_experiment.sh weights

# Re-derive Table 1 geometry and relative error reductions across 3 backbones:
python3 probes/report_families.py \
  results/residual/fw_families.npz Fast-WAM \
  results/residual/pi05_families.npz pi0.5 \
  results/residual/dz_families.npz DreamZero
```

### 7. List All Available Benchmark Experiments
```bash
./repro/run_experiment.sh list
```

---

## Repository Layout

```
├── inputs/
│   ├── weights/          # Calibrated least-squares attenuation weights (json)
│   └── manifests/        # Episode manifests and initial state index lists
├── probes/
│   ├── fw_libero.py      # Core closed-loop LIBERO evaluation probe
│   ├── gate_cache.py     # Same-input identity gate for numerical cache verification
│   ├── check_anonymity.py # Automated double-blind anonymity scanner
│   ├── report_*.py       # Analysis and statistical aggregation scripts
│   └── test_*.py         # Comprehensive unit and regression test suites
├── repro/
│   ├── verify_workshop.sh # Single-entrypoint CPU verification suite
│   ├── run_experiment.sh  # Experiment execution harness
│   ├── MANIFEST.md       # Audit manifest of all experimental runs
│   └── experiments/      # Individual experiment runner scripts
├── results/
│   ├── decisive_review_eval/ # Unified 11-arm single-host evaluation (Table 3b & §5)
│   ├── matched_frontier/     # Historical 6-arm matched frontier collection
│   ├── baseline_audit/   # Live GPU baseline validation outputs (logs, yaml, json)
│   ├── schedule_sensitivity.json # 500-state schedule sensitivity analysis
│   ├── canonical_numbers.json   # Canonical empirical numbers reported in paper
│   ├── residual/         # Multi-backbone Gram matrices and residual recordings
│   ├── tau8/             # 5-seed aggressive caching evaluations
│   ├── tau8_fresh/       # Fresh-process isolated tau=8 replication (seeds 42 & 7)
│   └── statescale/       # 500-state denoising step comparisons
└── setup/
    ├── HOST_REQUIREMENTS.md # Detailed hardware, driver, and CUDA specifications
    └── onstart_*.sh         # Automated host provisioning scripts
```

---

## Double-Blind Anonymity

This repository is formatted for double-blind review:
- All git commit history is authored as `Anonymous <anonymous@example.com>`.
- Automated check via `python3 probes/check_anonymity.py` confirms zero personal names, institutional emails, user accounts, or private host paths exist in tracked files.
