"""Model namespace for fastwam."""
