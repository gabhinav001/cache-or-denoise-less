#!/usr/bin/env bash
# Focused workshop verification. CPU only; does not install, provision, or mutate results.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PY:-python3}"
for test in test_cache_semantics test_stack_probe_audit test_report_published test_baseline_audit test_schedule_sensitivity test_checkpoint_coverage test_cache_integrity test_report_tau8_fresh; do
  "$PY" "$ROOT/probes/$test.py"
done
PYTHONPATH="$ROOT/probes${PYTHONPATH:+:$PYTHONPATH}" "$PY" - "$ROOT" <<'PYVERIFY'
import json,sys
from pathlib import Path
from report_schedule_sensitivity import analyze
root=Path(sys.argv[1])
frozen=json.loads((root/"results/schedule_sensitivity.json").read_text())
current=analyze(root/"results")
if "numpy" in current.get("method", {}):
    current["method"]["numpy"] = frozen.get("method", {}).get("numpy")
if frozen!=current:
    raise SystemExit("Schedule snapshot differs from raw-data analysis; inspect before regenerating")
print("Sensitivity snapshot, 24 source hashes, coverage, pairing, and intervals verified.")
PYVERIFY
"$PY" "$ROOT/probes/check_figure_data.py" "$ROOT/probes/workshop_figure_data.json"
"$PY" "$ROOT/probes/report_tau8_fresh.py" "$ROOT/results/tau8_fresh"
[ -d "$ROOT/results/matched_frontier" ] && "$PY" "$ROOT/probes/report_matched_frontier.py" "$ROOT/results/matched_frontier"
[ -d "$ROOT/results/decisive_review_eval" ] && "$PY" "$ROOT/probes/report_decisive_eval.py" "$ROOT/results/decisive_review_eval"
bash -n "$ROOT/repro/experiments/baseline_audit.sh"
for variant in original optional; do
  for phase in smoke pilot full; do
    DRY_RUN=1 BASELINE_VARIANT="$variant" BASELINE_PHASE="$phase" \
      bash "$ROOT/repro/run_experiment.sh" baseline_audit --seeds 42 --out /tmp/baseline-audit-dryrun >/dev/null
  done
done
echo "Workshop CPU checks passed. Pending GPU collections are not validated by these checks."
